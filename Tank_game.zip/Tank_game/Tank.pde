class Tank {
  float x, y, w, h, speed, health;
  PImage iTankW, iTankA, iTankS, iTankD;
  char idir;
  int turretCount, laserCount;

  Tank() {
    x = 250;
    y = 250;
    w = 100;
    h = 100;
    speed = 15;
    health = 75;

    iTankW = loadImage("TankW.png");
    iTankA = loadImage("TankA.png");
    iTankS = loadImage("TankS.png");
    iTankD = loadImage("TankD.png");
    idir = 'w';
    turretCount = 1;
    laserCount = 100;
  }

  void display() {
    imageMode(CENTER);

    if (idir == 'w') {
      image(iTankW, x, y);
      println("w");
    } else if (idir == 'a') {
      image(iTankA, x, y);
      println("a");
    } else if (idir == 's') {
      image(iTankS, x, y);
      println("s");
    } else if (idir == 'd') {
      image(iTankD, x, y);
      println("d");
    }

  }

  void move(char dir) {
    idir = dir;

    if (dir == 'w') {
      y = y - speed;
    } else if (dir == 's') {
      y = y + speed;
    } else if (dir == 'a') {
      x = x - speed;
    } else if (dir == 'd') {
      x = x + speed;
    }
  }

  void fire () {
  }
  boolean intersect(Obstacle o) {
    float distance = dist (x, y, o.x, o.y);
    if (distance < 100) {
      return true;
    } else {
      return false;
    }
  }
}
//class Tank {
//  float x, y, w, h, speed, health;
//  PImage iTankW, iTankA, iTankS, iTankD;
//  char idir;
//int turretCount, laserCount;

//  //constructor
//  Tank() {
//    x = 100.0;
//    y = 100.0;
//    w = 100.0;
//    h = 100.0;
//    speed = 5.0;
//    health = 100.0;
//    iTankW = loadImage("TankW.png");
//    iTankA = loadImage("TankA.png");
//    iTankS = loadImage("TankS.png");
//    iTankD = loadImage("TankD.png");
//    idir = 'w';
//  }
// void display() {
//    imageMode(CENTER);
//    if(idir == 'w') {
//      image(iTankW,x,y);
//    } else if(idir == 'a') {
//      image(iTankA,x,y);
//    } else if(idir == 's') {
//      image(iTankS,x,y);
//    } else if(idir == 'd') {
//      image(iTankD,x,y);
//    }
//  }

//  }
//  void wrap() {
//    if (y < 0) y = height;
//    if (y > height) y = 0;
//    if (x < 0) x = width;
//    if (x > width) x = 0;
//  }


//  void move(char idir) {
//    if (idir == 'w') {
//      idir = 'w';
//      y = y - speed;
//    } else if (idir == 's') {
//      idir = 's';
//      y = y + speed;
//    } else if (idir == 'a') {
//      idir = 'a';
//      x = x - speed;
//    } else if (idir == 'd') {
//      idir = 'd';
//      x = x + speed;
//    }
//  }
//      void fire() {
//  }
//  boolean intersect(Obstacle o) {
//    float distance = dist(x, y, o.x, o.y);
//    if (distance < 100) {
//      return true;
//    } else {
//      return false;
//    }
//  }
  
//}
